﻿$ErrorActionPreference = 'Stop'
$source = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'autopilot_loop.ps1'))
$errors = $null
[void][Management.Automation.Language.Parser]::ParseInput($source, [ref]$null, [ref]$errors)
if ($errors) { throw ($errors | Out-String) }
$bytes = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'autopilot_loop.ps1'))
if (($bytes[0..2] -join ',') -ne '239,187,191') { throw 'UTF-8 BOM missing' }
$start = $source.IndexOf('$progressCleanupPrompt = ')
$end = $source.IndexOf('# 지시개선 정책', $start)
$block = [scriptblock]::Create($source.Substring($start, $end - $start))
$ProjectDir = Join-Path ([IO.Path]::GetTempPath()) ('ap-check-' + [guid]::NewGuid())
$progressDir = Join-Path $ProjectDir 'autopilot/progress/test'
$progressMdRelPath = 'autopilot/AUTOPILOT_PROGRESS.md'
$runDate = 'test'
function Write-Log([string]$Text) { }
try {
    [void][IO.Directory]::CreateDirectory($progressDir)
    $path = Join-Path $ProjectDir $progressMdRelPath
    . $block
    if ($progressCleanupPrompt) { throw 'Missing file triggered cleanup' }
    foreach ($count in 200, 201) {
        [IO.File]::WriteAllLines($path, [string[]](1..$count))
        $original = [IO.File]::ReadAllText($path)
        . $block
        if ([IO.File]::ReadAllText($path) -cne $original) { throw 'Original changed' }
        if ($count -eq 200 -and $progressCleanupPrompt) { throw 'Threshold mismatch' }
        if ($count -eq 201) {
            if (-not $progressCleanupPrompt) { throw 'Cleanup prompt missing' }
            if ([IO.File]::ReadAllText($archivePath) -cne $original) { throw 'Archive mismatch' }
        }
    }
    $progressDir = Join-Path $ProjectDir 'missing-directory'
    . $block
    if ($progressCleanupPrompt) { throw 'Failed archive triggered cleanup' }
    if ([IO.File]::ReadAllText($path) -cne $original) { throw 'Failure changed original' }
    if (-not $source.Contains('${policyPrompt} ${progressCleanupPrompt}')) { throw 'Prompt not connected' }
    'OK: syntax, BOM, missing file, 200/201 lines, archive, failure, prompt'
} finally {
    $resolved = [IO.Path]::GetFullPath($ProjectDir)
    $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
    if ($resolved.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -and
        (Split-Path $resolved -Leaf) -like 'ap-check-*') {
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
